# Overview - Ethiopia Surveillance IG (sandbox demo subset) v0.1.0

* [**Table of Contents**](toc.md)
* **Overview**

## Overview

| | |
| :--- | :--- |
| *Official URL*:http://fhir.et/surveillance/ImplementationGuide/et.fhir.surveillance | *Version*:0.1.0 |
| Draft as of 2026-06-17 | *Computable Name*:ETSurveillance |

### Ethiopia Surveillance IG (sandbox demo subset)

Minimal surveillance IG derived from [`et.fhir.core`](http://fhir.et/core) for the conformance sandbox. Carries the surveillance extensions and (disabled) STI/VMMC/SRH content; the enabled subset supports the HIV IG and the medication-dispense demo.

